from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request, 'contas/dashboard.html' )

def produtos(request):
    return render(request, 'contas/produto.html' )

def opcoes(request):
    return render(request, 'contas/opcao.html' )

def calculadora(request):
    return render(request, 'contas/calculadora.html')

def apresentacao(request):
    return render(request, 'contas/apresentacao.html' )