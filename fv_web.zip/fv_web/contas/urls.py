from django.urls import path
from . import views




urlpatterns = [
    path('home/', views.home),
    path('produto/', views.produtos ),
    path('opcoes/', views.opcoes ),
    path('calculadora/',views.calculadora),
    path('apresentacao/', views.apresentacao),
]